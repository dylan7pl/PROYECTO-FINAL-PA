package server

import (
	"backend-avanzada/api"
	"backend-avanzada/models"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"strconv"
	"time"

	"github.com/gorilla/mux"
)

func (s *Server) HandleKills(w http.ResponseWriter, r *http.Request) {
	switch r.Method {
	case http.MethodGet:
		s.handleGetAllKills(w, r)
		return
	case http.MethodPost:
		s.handleCreateKill(w, r)
		return
	}
}

func (s *Server) HandleKillsWithId(w http.ResponseWriter, r *http.Request) {
	s.handleGetKillById(w, r)
}
func (s *Server) handleUpdate(w http.ResponseWriter, r *http.Request) {
	s.handleUpdateKill(w, r)
}

func (s *Server) handleGetAllKills(w http.ResponseWriter, r *http.Request) {
	start := time.Now()
	result := []*api.KillResponseDto{}
	kills, err := s.KillRepository.FindAll()
	if err != nil {
		s.HandleError(w, http.StatusInternalServerError, r.URL.Path, err)
		return
	}
	for _, v := range kills {
		result = append(result, v.ToKillResponseDto())
	}
	response, err := json.Marshal(result)
	if err != nil {
		s.HandleError(w, http.StatusInternalServerError, r.URL.Path, err)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	w.Write(response)
	s.logger.Info(http.StatusOK, r.URL.Path, start)
}

func (s *Server) handleGetKillById(w http.ResponseWriter, r *http.Request) {
	start := time.Now()
	vars := mux.Vars(r)
	id, err := strconv.ParseInt(vars["id"], 10, 32)
	if err != nil {
		s.HandleError(w, http.StatusBadRequest, r.URL.Path, err)
		return
	}
	k, err := s.KillRepository.FindById(int(id))
	if k == nil && err == nil {
		s.HandleError(w, http.StatusNotFound, r.URL.Path, fmt.Errorf("person with id %d not found", id))
		return
	}
	if err != nil {
		s.HandleError(w, http.StatusInternalServerError, r.URL.Path, err)
		return
	}
	resp := k.ToKillResponseDto()
	response, err := json.Marshal(resp)
	if err != nil {
		s.HandleError(w, http.StatusInternalServerError, r.URL.Path, err)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	w.Write(response)
	s.logger.Info(http.StatusOK, r.URL.Path, start)
}

func (s *Server) handleCreateKill(w http.ResponseWriter, r *http.Request) {
	start := time.Now()

	err := r.ParseMultipartForm(10 << 20)
	if err != nil {
		s.HandleError(w, http.StatusBadRequest, r.URL.Path, fmt.Errorf("formato inválido: %v", err))
		return
	}

	firstName := r.FormValue("firstName")
	lastName := r.FormValue("lastName")
	causeOfDeath := r.FormValue("causeOfDeath")
	details := r.FormValue("details")

	if firstName == "" || lastName == "" {
		s.HandleError(w, http.StatusBadRequest, r.URL.Path, fmt.Errorf("firstName y lastName son requeridos"))
		return
	}

	file, handler, err := r.FormFile("photo")
	if err != nil {
		s.HandleError(w, http.StatusBadRequest, r.URL.Path, fmt.Errorf("archivo de imagen requerido"))
		return
	}
	defer file.Close()

	os.MkdirAll("uploads", os.ModePerm)
	fileName := fmt.Sprintf("%d_%s", time.Now().Unix(), handler.Filename)
	savePath := fmt.Sprintf("uploads/%s", fileName)
	publicURL := fmt.Sprintf("/static/%s", fileName)

	dst, err := os.Create(savePath)
	if err != nil {
		s.HandleError(w, http.StatusInternalServerError, r.URL.Path, fmt.Errorf("no se pudo guardar imagen"))
		return
	}
	defer dst.Close()
	io.Copy(dst, file)

	now := time.Now()
	kill := &models.Kill{
		FirstName:    firstName,
		LastName:     lastName,
		FaceImageURL: publicURL,
		CauseOfDeath: causeOfDeath,
		Details:      details,
		CreatedAt:    now,
	}

	var duration time.Duration
	if causeOfDeath == "" {
		duration = time.Duration(s.Config.KillDuration) * time.Second
	} else if details != "" {
		duration = time.Duration(s.Config.KillDurationWithDescription) * time.Second
	} else {
		duration = time.Duration(s.Config.KillDuration) * time.Second
	}

	saved, err := s.KillRepository.Save(kill)
	if err != nil {
		s.HandleError(w, http.StatusInternalServerError, r.URL.Path, err)
		return
	}

	s.taskQueue.StartTask(int(saved.ID), duration, func(k *models.Kill) error {
		now := time.Now()
		k.DeathTime = &now
		_, err := s.KillRepository.Update(int(k.ID), k)
		return err
	}, saved)

	resp := api.KillTaskResponseDto{
		ID:      saved.ID,
		Status:  "Scheduled",
		DeathAt: time.Now().Add(duration).Format(time.RFC3339),
	}

	result, err := json.Marshal(resp)
	if err != nil {
		s.HandleError(w, http.StatusInternalServerError, r.URL.Path, err)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusCreated)
	w.Write(result)
	s.logger.Info(http.StatusCreated, r.URL.Path, start)
}

func (s *Server) handleUpdateKill(w http.ResponseWriter, r *http.Request) {
	start := time.Now()
	var dto api.KillRequestDto
	vars := mux.Vars(r)
	id, err := strconv.Atoi(vars["id"])
	if err != nil {
		s.HandleError(w, http.StatusBadRequest, r.URL.Path, err)
		return
	}

	kill, err := s.KillRepository.FindById(id)
	if err != nil || kill == nil {
		s.HandleError(w, http.StatusNotFound, r.URL.Path, fmt.Errorf("Kill not found"))
		return
	}

	if err := json.NewDecoder(r.Body).Decode(&dto); err != nil {
		s.HandleError(w, http.StatusBadRequest, r.URL.Path, err)
		return
	}

	now := time.Now()

	if dto.CauseOfDeath != "" && kill.CauseOfDeath == "" {
		kill.CauseOfDeath = dto.CauseOfDeath
		kill.CauseWrittenAt = &now
	}
	if dto.Details != "" && kill.Details == "" {
		kill.Details = dto.Details
		// kill.DetailsWrittenAt = &now
	}

	updated, err := s.KillRepository.Update(id, kill)
	if err != nil {
		s.HandleError(w, http.StatusInternalServerError, r.URL.Path, err)
		return
	}

	response, err := json.Marshal(updated.ToKillResponseDto())
	if err != nil {
		s.HandleError(w, http.StatusInternalServerError, r.URL.Path, err)
		return
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusOK)
	w.Write(response)
	s.logger.Info(http.StatusOK, r.URL.Path, start)
}

// func (s *Server) handleCreateKill(w http.ResponseWriter, r *http.Request) {
// 	start := time.Now()
// 	var k api.KillRequestDto
// 	var duration time.Duration
// 	err := json.NewDecoder(r.Body).Decode(&k)
// 	if err != nil {
// 		w.WriteHeader(http.StatusBadRequest)
// 		return
// 	}
// 	vars := mux.Vars(r)
// 	id, err := strconv.ParseInt(vars["id"], 10, 32)
// 	if err != nil {
// 		w.WriteHeader(http.StatusBadRequest)
// 	}
// 	_, exists := s.taskQueue.tasks[int(id)]
// 	if exists {
// 		s.HandleError(w, http.StatusConflict, r.URL.Path, fmt.Errorf("task with id %d is already in progress", id))
// 		return
// 	}
// 	if err != nil {
// 		w.WriteHeader(http.StatusInternalServerError)
// 		return
// 	}
// 	kill, err := s.KillRepository.FindById(int(id))
// 	if kill != nil {
// 		w.WriteHeader(http.StatusConflict)
// 		return
// 	}
// 	if err != nil {
// 		w.WriteHeader(http.StatusInternalServerError)
// 		return
// 	}
// 	kill = &models.Kill{
// 		Details: k.Details,
// 	}
// 	if strings.Compare(k.Details, "") == 0 {
// 		duration = time.Duration(s.Config.KillDuration) * time.Second
// 	} else {
// 		duration = time.Duration(s.Config.KillDurationWithDescription) * time.Second
// 	}
// 	killFunc := func(k *models.Kill) error {
// 		_, err := s.KillRepository.Save(k)
// 		if err != nil {
// 			return err
// 		}
// 		return nil
// 	}
// 	s.taskQueue.StartTask(int(kill.ID), duration, killFunc, kill)
// 	result, err := json.Marshal(&api.KillTaskResponseDto{
// 		Status: "In progress.",
// 	})
// 	if err != nil {
// 		w.WriteHeader(http.StatusInternalServerError)
// 		return
// 	}
// 	w.Header().Set("Content-Type", "application/json")
// 	w.WriteHeader(http.StatusCreated)
// 	w.Write(result)
// 	s.logger.Info(http.StatusCreated, r.URL.Path, start)
// }
